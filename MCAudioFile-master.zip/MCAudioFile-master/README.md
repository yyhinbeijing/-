MCAudioFile
===========

a simple wrapper of AudioFile

一个简单的AudioFile封装

相关的Blog：http://msching.github.io/blog/2014/07/19/audio-in-ios-4/