//
//  AppDelegate.h
//  MCAudioFile
//
//  Created by Chengyin on 14-8-10.
//  Copyright (c) 2014年 Chengyin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
