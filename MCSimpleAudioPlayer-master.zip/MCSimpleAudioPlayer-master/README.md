MCSimpleAudioPlayer
===================

Simple local audio file player
