//
//  ViewController.h
//  MCSimpleAudioPlayerDemo
//
//  Created by Chengyin on 14-7-29.
//  Copyright (c) 2014年 Chengyin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic,readwrite) IBOutlet UIButton *playOrPauseButton;
@property (nonatomic,readwrite) IBOutlet UISlider *progressSlider;

@end
