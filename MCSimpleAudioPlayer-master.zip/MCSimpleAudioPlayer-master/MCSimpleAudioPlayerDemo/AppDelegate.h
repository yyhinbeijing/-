//
//  AppDelegate.h
//  MCSimpleAudioPlayerDemo
//
//  Created by Chengyin on 14-7-29.
//  Copyright (c) 2014年 Chengyin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
