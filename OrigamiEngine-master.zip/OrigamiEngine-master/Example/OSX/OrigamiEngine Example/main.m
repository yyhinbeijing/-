//
//  main.m
//  OrigamiEngine Example
//
//  Created by Arthur Evstifeev on 9/02/13.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
