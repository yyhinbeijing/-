//
//  ORGMAppDelegate.h
//  OrigamiEngine Example
//
//  Created by Arthur Evstifeev on 9/02/13.
//
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;
@property (weak) IBOutlet NSView *mainView;

@end
