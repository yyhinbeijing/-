//
//  ORGMPlayerViewController.h
//  OrigamiEngine Example
//
//  Created by Arthur Evstifeev on 9/02/13.
//
//

#import <Cocoa/Cocoa.h>

@interface PlayerViewController : NSViewController

@end
