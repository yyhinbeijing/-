//
//  ORGMAppDelegate.h
//  ORGMEngine Example
//
//  Created by ap4y on 8/5/12.
//  Copyright (c) 2012 ap4y. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
